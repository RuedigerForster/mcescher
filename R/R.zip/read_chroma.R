source("./import/import_chromas.R")
source("./compress/compress.R")
source("./swarbled/swarbled.R")
source("./sass/sass.R")

library(lubridate)


tm <- Sys.time()
sample_types <- factor(c("UNKNOWN", "CONTROL", "CALIB", "BLANK"), ordered = TRUE,
                       levels = c("UNKNOWN", "CONTROL", "CALIB", "BLANK"))

# save plot parameters
safe <- par(no.readonly = TRUE)

# load data
path <- "~/Desktop/Basislinien/data/"
pattern = c("^UNIS_FID", ".cdf$")
df <- import_chromas(path, pattern)
# this is because sample_type was not entered correctly by the operator
attr(df, "sample_type") <- rep("4", ncol(df))

# indexing sampletypes
blanks <- as.integer(attr(df, "sample_type")) == which(sample_types == "BLANK")
calibs <- as.integer(attr(df, "sample_type")) == which(sample_types == "CALIB")
samples <- as.integer(attr(df, "sample_type")) == which(sample_types == "UNKNOWN")
controls <- as.integer(attr(df, "sample_type")) == which(sample_types == "CONTROL")

# order the columns by run_datetime in ascending order and apply filter
idx <- order(lubridate::as_datetime(attr(df, "run_datetime")))

# "BLANK" = baselines
idx <- idx[blanks]
df2 <- sapply(idx, function(x) df[, x])

# downsampling baseline data
x_factor <- 10L
y_factor <- 1L
lt <- nrow(df2) - nrow(df2) %% x_factor
df2 <- compress_mat(df[1:lt, ], c(x_factor, y_factor))
# # alternative: df2 with uncompressed data
# df2 <- df

# block baseline artifacts (switching valves)
block <- swarbled(df2, thresh = 3.29, blind = 30)

# SASS smoothing
# Define low-pass filter parameters
d <- 2; fc <- 0.022
# SASS - run algorithm
K <- 1; lam <- 1.2
df3 <- matrix(NA, nrow = dim(df2)[1], ncol = dim(df2)[2])
for (s in seq_along(block$segments)) {
  idx <- block$segments[[s]]['begin']:block$segments[[s]]['end']
  for (x in seq_len(ncol(df2))) {
    y <- as.numeric(df2[idx, x])
    sass_res <- sass_L1(y, d, fc, K, lam)
    df3[idx, x] <- as.matrix(sass_res$x)
  }
}

# calculate RMSE of fitted baselines
RMSE <- sapply(seq_len(ncol(df3)), function(i)
  (sqrt((df3[, i] - df2[, i])^2))
)
index <- 1:nrow(RMSE)
RMSE_fit <- lapply(seq_len(ncol(RMSE)), function(i) 
  loess(RMSE[, i] ~ index, span = 0.05, na.action = na.omit)
)
RMSE_pred <- matrix(ncol = ncol(RMSE), nrow = nrow(RMSE))
idx <- !is.na(RMSE[, 1])
RMSE_pred[idx, ] <- sapply(seq_len(ncol(df3)), function(i) 
  predict(RMSE_fit[[i]])
)

areaplot::confplot(cbind(index, df3[,35] - 5 * RMSE_pred[ , 35], df3[,35] + 5 * RMSE_pred[ , 35]), ylim = c(14.5, 16.7))
lines(df3[,35], type = "l", ylim = c(15, 18))



