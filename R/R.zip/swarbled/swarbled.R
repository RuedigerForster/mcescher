MAD <- function(y, k = 1.4826) {
  # median absolute deviation
  d <- sapply(seq_len(ncol(y)), function(i) c(0, diff(y[, i])))
  d_med <- sapply(seq_len(ncol(y)), function(i) median(d[, i]))
  return(k * d_med * abs(d - d_med))
}


swarbled <- function(df, thresh = 3.29, blind = 30) {
  # SWitching ARtifacts BLock Enable / Disable
  # 1st derivatives of baselines
  X <- scale(sapply(seq_len(ncol(df)), function(x) c(0, diff(df[, x]))))
  # select baselines which correlate best with 1st baseline
  idx <- sapply(seq_len(ncol(X)), function(x) cor(X[, x], X[, 1], method = "pearson", use = "complete.obs")) > 0.5
  MAD_X <- rowSums(MAD(X[, idx]))

  block <- vector(mode = "logical", length = nrow(df))
  block[MAD_X >= (quantile(MAD_X)[4] * thresh)] <- TRUE

  runs <- c(0, rle(diff(block)))
  falling <- which(runs$values == -1)
  rising <- which(runs$values == 1)
  
  if (!identical(length(falling), length(rising))) browser()
  
  # eliminate orphans / apply blind
  for (i in 1:(length(falling)-1)) {
    lo <- (sum(runs$lengths[1:falling[i]]) ) : (sum(runs$lengths[1:rising[i+1]]))
    if (length(lo) < blind) {
      block[lo] <- TRUE
    }
  }
  runs <- c(0, rle(diff(block)))
  falling <- which(runs$values == -1)
  rising <- which(runs$values == 1)
  good <- list()
  # good segments start with falling and end with rising
  for (i in 1:(length(rising)-1)) {
    begin <- sum(runs$lengths[1:falling[i]])
    end = sum(runs$lengths[1:rising[i+1]])
    # print(paste0(i, ": ", end - begin))
    if ((end - begin) > blind) {
      good[[i]] <- c(begin = begin, end = end)
    }
  }
  # last segment
  good[[i+1]] <- c(begin = sum(runs$lengths[1:falling[i+1]]), end = nrow(df))
  # first segment
  end <- sum(runs$lengths[1:rising[1]])
  if (end > blind) {
    good <- c(list(c(begin = 1, end = end)), good)
    block[1:end] <- TRUE
  }
  # reconfigure block
  block <- rep(TRUE, nrow(df))
  for (i in seq_along(good)) {
    block[good[[i]]['begin']:good[[i]]['end']] <- FALSE
  }
  
  return(list(block = block, segments = good))
}

  

